package com.vsc.vehicle_service_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleServiceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleServiceBackendApplication.class, args);
	}

}
