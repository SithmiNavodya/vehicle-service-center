package com.vsc.vehicle_service_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleServiceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
